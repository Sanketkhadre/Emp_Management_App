package com.cts.Employee.Management.App.Poc;

import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;

import com.cts.Employee.Management.App.Poc.repo.Employeerepo;

@SpringBootTest
class EmployeeManagementAppPocApplicationTests {
	

	@Test
	void contextLoads() {
		
		
	}

}
